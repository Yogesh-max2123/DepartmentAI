from __future__ import annotations

from collections import Counter
from pathlib import Path
import sys

from module2.ingestion.faculty_publications_final import parse_publication_pdf

ROOT = Path("module2/ingestion/raw_sources")


def main() -> int:
    if not ROOT.exists():
        print(f"Cached PDF folder not found: {ROOT}")
        return 2

    pdfs = sorted(ROOT.rglob("publications.pdf"))
    print(f"Cached publication PDFs found: {len(pdfs)}")
    empty: list[Path] = []
    total_records = 0

    for pdf in pdfs:
        faculty = pdf.parent.name.replace("_", " ")
        try:
            records = parse_publication_pdf(pdf, faculty_name=faculty)
            types = Counter(record.publication_type for record in records)
            total_records += len(records)
            print(f"{pdf.parent.name}: {len(records)} records | {dict(types)}")
            for record in records[:2]:
                print(f"  - [{record.publication_type}] {record.title[:140]}")
            if not records:
                empty.append(pdf)
        except Exception as exc:
            empty.append(pdf)
            print(f"{pdf.parent.name}: ERROR {type(exc).__name__}: {exc}")

    print("\nPARSER TEST SUMMARY")
    print(f"PDFs tested: {len(pdfs)}")
    print(f"PDFs producing records: {len(pdfs) - len(empty)}")
    print(f"Total parsed records: {total_records}")
    print(f"PDFs needing investigation: {len(empty)}")
    for path in empty:
        print(f"  - {path}")

    return 1 if empty else 0


if __name__ == "__main__":
    raise SystemExit(main())
